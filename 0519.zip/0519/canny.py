import numpy as np, sys, cv2

video = cv2.VideoCapture("my.mp4")
# 비디오 객체가 정상적으로 open 되었는지 확인

if not video.isOpened():
    print('video open failed!')
    sys.exit()

cv2.namedWindow('Canny Edge', 0)

while True:

    check, frame = video.read()
    # 카메라에서 이미지 얻기. 비디오의 한 프레임씩 읽기,
    # 제대로 프레임을 읽으면 ret값이 True 실패하면 False,
    # frame에는 읽은 프레임이 나옴
    gaussian = cv2.GaussianBlur(frame, (5, 5), 0) # 노이즈 제거 - 얻어온 프레임에 대해 5x5 가우시안 필터 먼저 적용

    width = round(video.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = round(video.get(cv2.CAP_PROP_FRAME_HEIGHT))

    frame = cv2.Canny(gaussian, 100, 150)


    cv2.imshow('Canny Edge', frame)
    if cv2.waitKey(1) == 32:
        break

fps = video.get(cv2.CAP_PROP_FPS)
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
# 1프레임과 다음 프레임 사이의 간격 설정
delay = round(1000/fps)

# 웹캠으로 찰영한 영상을 저장하기
# cv2.VideoWriter 객체 생성, 기존에 받아온 속성값 입력
out = cv2.VideoWriter('canny.mp4', fourcc, fps, (int(video.get(3)),int(video.get(4))))
out.release()
cv2.destroyAllWindows()
